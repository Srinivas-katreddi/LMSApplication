package org.example.lmsapplication.config;

import org.example.lmsapplication.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

     private final CustomUserDetailsService uds;
    @Autowired
    public SecurityConfig(CustomUserDetailsService uds) {
        this.uds = uds;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login.html","/css/**","/js/**","/api/auth/**").permitAll()
                        .requestMatchers("/api/employee/**","/employee-dashboard.html").hasRole("EMPLOYEE")
                        .requestMatchers("/api/manager/**","/manager-dashboard.html").hasRole("MANAGER")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login.html")
                        .loginProcessingUrl("/api/auth/login")
                        .successHandler((req,res,auth) -> {
                            boolean isMgr = auth.getAuthorities().stream()
                                    .anyMatch(a -> a.getAuthority().equals("ROLE_MANAGER"));
                            res.sendRedirect(isMgr ? "/manager-dashboard.html" : "/employee-dashboard.html");
                        })
                        .failureUrl("/login.html?error=true")
                        .permitAll()
                )
                .logout(l -> l.logoutUrl("/api/auth/logout").logoutSuccessUrl("/login.html"));
        return http.build();
    }
}
