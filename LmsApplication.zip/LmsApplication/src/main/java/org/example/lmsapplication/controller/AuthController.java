package org.example.lmsapplication.controller;

public class AuthController {
}
