package org.example.lmsapplication.controller;

import org.example.lmsapplication.dto.LeaveRequestDTO;
import org.example.lmsapplication.entity.*;
import org.example.lmsapplication.repository.*;
import org.example.lmsapplication.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {
    @Autowired
    LeaveService leaveService;
    @Autowired
    EmployeeRepository eRepo;
    @Autowired
    LeaveBalanceRepository lbRepo;
    @Autowired
    LeaveRequestRepository lrRepo;
    @Autowired
    LeaveTypeRepository ltRepo;

    @GetMapping("/me")
    public Employee me(Principal p) { return eRepo.findByEemail(p.getName()).orElseThrow(); }

    @GetMapping("/balances")
    public List<LeaveBalance> balances(Principal p) {
        return lbRepo.findByEmployee_Eid(eRepo.findByEemail(p.getName()).get().getEid());
    }

    @GetMapping("/leave-types")
    public List<LeaveType> types() { return ltRepo.findAll(); }

    @GetMapping("/history")
    public List<LeaveRequest> history(Principal p) {
        return lrRepo.findByEmployee_EidOrderByAppliedDateDesc(
                eRepo.findByEemail(p.getName()).get().getEid());
    }

    @PostMapping("/apply")
    public Map<String,String> apply(Principal p, @RequestBody LeaveRequestDTO dto) {
        String msg = leaveService.applyLeave(p.getName(), dto.getLtid(),
                dto.getFromDate(), dto.getToDate(), dto.getReason(), dto.isHalfDay());
        return Map.of("message", msg);
    }
}

