package org.example.lmsapplication.controller;

import org.example.lmsapplication.entity.LeaveRequest;
import org.example.lmsapplication.entity.Manager;
import org.example.lmsapplication.repository.LeaveRequestRepository;
import org.example.lmsapplication.repository.ManagerRepository;
import org.example.lmsapplication.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/manager")
public class ManagerController {
    private final LeaveService leaveService;
    private final ManagerRepository mRepo;
    private final LeaveRequestRepository lrRepo;
    @Autowired
    public ManagerController(LeaveService leaveService, ManagerRepository mRepo, LeaveRequestRepository lrRepo) {
        this.leaveService = leaveService;
        this.mRepo = mRepo;
        this.lrRepo = lrRepo;
    }

    @GetMapping("/me")
    public Manager me(Principal p) { return mRepo.findByMemail(p.getName()).orElseThrow(); }

    @GetMapping("/requests")
    public List<LeaveRequest> requests(Principal p) {
        Manager m = mRepo.findByMemail(p.getName()).orElseThrow();
        return lrRepo.findByEmployee_Manager_MidOrderByAppliedDateDesc(m.getMid());
    }

    @PostMapping("/update-status/{lid}")
    public Map<String,String> update(@PathVariable Integer lid, @RequestParam String status) {
        leaveService.updateStatus(lid, status);
        return Map.of("message", "Updated");
    }
}
