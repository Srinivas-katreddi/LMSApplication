package org.example.lmsapplication.controller;

import org.example.lmsapplication.entity.LeaveRequest;
import org.example.lmsapplication.entity.Manager;
import org.example.lmsapplication.repository.LeaveRequestRepository;
import org.example.lmsapplication.repository.ManagerRepository;
import org.example.lmsapplication.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/manager")
public class ManagerController {
    @Autowired
    LeaveService leaveService;
    @Autowired
    ManagerRepository mRepo;
    @Autowired
    LeaveRequestRepository lrRepo;

    @GetMapping("/requests")
    public List<LeaveRequest> requests(Principal p) {
        Manager m = mRepo.findByMemail(p.getName()).orElseThrow();
        return lrRepo.findByEmployee_Manager_MidOrderByAppliedDateDesc(m.getMid());
    }

    @PostMapping("/update-status/{lid}")
    public Map<String,String> update(@PathVariable Integer lid, @RequestParam String status) {
        leaveService.updateStatus(lid, status);
        return Map.of("message", "Updated");
    }
}
