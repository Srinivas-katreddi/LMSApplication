package org.example.lmsapplication.dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
public class LeaveRequestDTO {
    private Integer ltid;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String reason;
    private boolean halfDay;
}
