package org.example.lmsapplication.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Entity
@Table(name = "employee")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Employee {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer eid;
    private String ename;
    @Column(unique = true) private String eemail;
    private String epassword;
    private String edept;
    private LocalDate ejoiningDate;
    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;
}