package org.example.lmsapplication.entity;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "leave_balance",
        uniqueConstraints = @UniqueConstraint(columnNames = {"eid","ltid"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveBalance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer lbid;
    @ManyToOne
    @JoinColumn(name = "eid")
    private Employee employee;
    @ManyToOne
    @JoinColumn(name = "ltid")
    private LeaveType leaveType;
    private Integer availabledays = 0;
}