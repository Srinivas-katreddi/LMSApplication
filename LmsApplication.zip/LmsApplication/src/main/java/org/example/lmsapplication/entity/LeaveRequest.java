package org.example.lmsapplication.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "leave_request")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer lid;
    @ManyToOne
    @JoinColumn(name = "eid")
    private Employee employee;
    @ManyToOne
    @JoinColumn(name = "ltid")
    private LeaveType leaveType;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String reason;
    private String status = "PENDING";
    private LocalDate appliedDate;
    private LocalDate approvedDate;
}