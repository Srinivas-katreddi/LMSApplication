package org.example.lmsapplication.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "leavetype")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LeaveType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ltid;
    @Column(unique = true)
    private String leavename;
}