package org.example.lmsapplication.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Entity
@Table(name = "manager")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Manager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer mid;
    private String mname;
    @Column(unique = true)
    private String memail;
    private String mpassword;
    private String mdept;
    private LocalDate mjoiningDate;
}