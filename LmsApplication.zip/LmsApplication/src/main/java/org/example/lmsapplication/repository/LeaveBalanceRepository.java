package org.example.lmsapplication.repository;

import org.example.lmsapplication.entity.LeaveBalance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance,Integer> {
    Optional<LeaveBalance> findByEmployee_EidAndLeaveType_Ltid(Integer eid, Integer ltid);
    List<LeaveBalance> findByEmployee_Eid(Integer eid);
}