package org.example.lmsapplication.repository;

import org.example.lmsapplication.entity.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest,Integer> {
    List<LeaveRequest> findByEmployee_EidOrderByAppliedDateDesc(Integer eid);
    List<LeaveRequest> findByEmployee_Manager_MidOrderByAppliedDateDesc(Integer mid);
}