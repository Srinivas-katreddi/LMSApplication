package org.example.lmsapplication.repository;

import org.example.lmsapplication.entity.LeaveType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LeaveTypeRepository extends JpaRepository<LeaveType,Integer> {
    Optional<LeaveType> findByLeavename(String name);
}