package org.example.lmsapplication.repository;

import org.example.lmsapplication.entity.Manager;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ManagerRepository extends JpaRepository<Manager,Integer> {
    Optional<Manager> findByMemail(String email);
}