package org.example.lmsapplication.service;

import org.example.lmsapplication.entity.Employee;
import org.example.lmsapplication.entity.Manager;
import org.example.lmsapplication.repository.EmployeeRepository;
import org.example.lmsapplication.repository.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    private final ManagerRepository mr;
    private final EmployeeRepository er;
    @Autowired
    public CustomUserDetailsService(ManagerRepository mr, EmployeeRepository er) {
        this.mr = mr;
        this.er = er;
    }

    @Override
    public UserDetails loadUserByUsername(String email) {

        Optional<Manager> managerOpt = mr.findByMemail(email);

        if (managerOpt.isPresent()) {
            Manager m = managerOpt.get();

            return User.withUsername(m.getMemail())
                    .password(m.getMpassword())
                    .roles("MANAGER")
                    .build();
        }
        Optional<Employee> employeeOpt = er.findByEemail(email);

        if (employeeOpt.isPresent()) {
            Employee e = employeeOpt.get();

            return User.withUsername(e.getEemail())
                    .password(e.getEpassword())
                    .roles("EMPLOYEE")
                    .build();
        }

        throw new UsernameNotFoundException("Not found");
    }
}
