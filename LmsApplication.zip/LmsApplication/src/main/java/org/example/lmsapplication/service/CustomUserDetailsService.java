package org.example.lmsapplication.service;

import org.example.lmsapplication.repository.EmployeeRepository;
import org.example.lmsapplication.repository.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    ManagerRepository mr;
    @Autowired
    EmployeeRepository er;

    @Override
    public UserDetails loadUserByUsername(String email) {
        return mr.findByMemail(email)
                .map(m -> User.withUsername(m.getMemail())
                        .password(m.getMpassword()).roles("MANAGER").build())
                .orElseGet(() -> er.findByEemail(email)
                        .map(e -> User.withUsername(e.getEemail())
                                .password(e.getEpassword()).roles("EMPLOYEE").build())
                        .orElseThrow(() -> new UsernameNotFoundException("Not found")));
    }
}
