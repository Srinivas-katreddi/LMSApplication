package org.example.lmsapplication.service;

public class EmployeeService {
}
