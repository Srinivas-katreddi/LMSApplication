package org.example.lmsapplication.service;

import jakarta.transaction.Transactional;
import org.example.lmsapplication.entity.Employee;
import org.example.lmsapplication.entity.LeaveBalance;
import org.example.lmsapplication.entity.LeaveRequest;
import org.example.lmsapplication.repository.EmployeeRepository;
import org.example.lmsapplication.repository.LeaveBalanceRepository;
import org.example.lmsapplication.repository.LeaveRequestRepository;
import org.example.lmsapplication.repository.LeaveTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;

@Service
public class LeaveService {
    private final LeaveRequestRepository lrRepo;
    private final LeaveBalanceRepository lbRepo;
    private final EmployeeRepository eRepo;
    private final LeaveTypeRepository ltRepo;
    @Autowired
    public LeaveService(LeaveRequestRepository lrRepo, LeaveBalanceRepository lbRepo, EmployeeRepository eRepo, LeaveTypeRepository ltRepo) {
        this.lrRepo = lrRepo;
        this.lbRepo = lbRepo;
        this.eRepo = eRepo;
        this.ltRepo = ltRepo;
    }

    public double calculateDays(LocalDate from, LocalDate to, boolean halfDay) {
        double days = 0;
        LocalDate d = from;
        while (!d.isAfter(to)) {
            DayOfWeek dow = d.getDayOfWeek();
            if (dow != DayOfWeek.SATURDAY && dow != DayOfWeek.SUNDAY) days++;
            d = d.plusDays(1);
        }
        if (halfDay && days > 0) days -= 0.5;
        return days;
    }

    @Transactional
    public String applyLeave(String email, Integer ltid, LocalDate from,
                             LocalDate to, String reason, boolean halfDay) {
        Employee emp = eRepo.findByEemail(email).orElseThrow();
        if (from.isBefore(LocalDate.now()))
            return "From date cannot be in the past";
        if (to.isBefore(from)) return "To date must be after from date";

        double days = calculateDays(from, to, halfDay);
        if (days <= 0) return "Selected range has no working days";

        LeaveBalance bal = lbRepo
                .findByEmployee_EidAndLeaveType_Ltid(emp.getEid(), ltid)
                .orElseThrow(() -> new RuntimeException("No balance row"));

        if (bal.getAvailabledays() < days)
            return "This type of leave is not available for " + days + " days";

        LeaveRequest lr = new LeaveRequest();
        lr.setEmployee(emp);
        lr.setLeaveType(ltRepo.findById(ltid).orElseThrow());
        lr.setFromDate(from);
        lr.setToDate(to);
        lr.setReason(reason);
        lr.setStatus("PENDING");
        lr.setAppliedDate(LocalDate.now());
        lrRepo.save(lr);
        return "SUCCESS";
    }

    @Transactional
    public void updateStatus(Integer lid, String status) {
        LeaveRequest lr = lrRepo.findById(lid).orElseThrow();
        if (!"PENDING".equals(lr.getStatus())) return;
        lr.setStatus(status);
        lr.setApprovedDate(LocalDate.now());

        if ("APPROVED".equals(status)) {
            double days = calculateDays(lr.getFromDate(), lr.getToDate(), false);
            LeaveBalance bal = lbRepo
                    .findByEmployee_EidAndLeaveType_Ltid(
                            lr.getEmployee().getEid(), lr.getLeaveType().getLtid())
                    .orElseThrow();
            bal.setAvailabledays(bal.getAvailabledays() - (int)Math.ceil(days));
        }
    }

}
