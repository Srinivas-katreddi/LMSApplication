package org.example.lmsapplication.service;

public class ManagerService {
}
