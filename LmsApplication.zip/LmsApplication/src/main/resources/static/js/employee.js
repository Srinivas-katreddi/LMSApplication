const today = new Date().toISOString().split('T')[0];
document.getElementById('fromDate').min = today;
document.getElementById('toDate').min = today;

// Disable weekends client-side
function isWeekend(dateStr) {
  const d = new Date(dateStr).getDay();
  return d === 0 || d === 6;
}
['fromDate','toDate'].forEach(id => {
  document.getElementById(id).addEventListener('change', e => {
    if (isWeekend(e.target.value)) {
      alert('Weekends are not allowed');
      e.target.value = '';
    }
    updateDayCount();
  });
});

function workingDays(from, to, half) {
  let d = new Date(from), end = new Date(to), count = 0;
  while (d <= end) {
    const day = d.getDay();
    if (day !== 0 && day !== 6) count++;
    d.setDate(d.getDate() + 1);
  }
  if (half && count > 0) count -= 0.5;
  return count;
}

function updateDayCount() {
  const f = document.getElementById('fromDate').value;
  const t = document.getElementById('toDate').value;
  const h = document.getElementById('halfDay').value === 'true';
  if (f && t) {
    const n = workingDays(f, t, h);
    document.getElementById('dayCount').innerText = `Total working days: ${n}`;
  }
}
document.getElementById('halfDay').addEventListener('change', updateDayCount);

async function loadDashboard() {
  const me = await fetch('/api/employee/me').then(r => r.json());
  document.getElementById('empName').innerText = me.ename;

  const balances = await fetch('/api/employee/balances').then(r => r.json());
  const total = balances.reduce((s,b) => s + b.availabledays, 0);

  let html = `<div class="card"><h3>Total Available</h3><h1>${total}</h1></div>`;
  balances.forEach(b => {
    html += `<div class="card"><h4>${b.leaveType.leavename}</h4><h2>${b.availabledays}</h2></div>`;
  });
  document.getElementById('balances').innerHTML = html;

  const types = await fetch('/api/employee/leave-types').then(r => r.json());
  document.getElementById('leaveType').innerHTML =
    types.map(t => `<option value="${t.ltid}">${t.leavename}</option>`).join('');

  loadHistory();
}

async function loadHistory() {
  const data = await fetch('/api/employee/history').then(r => r.json());
  let html = `<tr><th>Type</th><th>From</th><th>To</th><th>Applied</th><th>Reason</th><th>Status</th></tr>`;
  data.forEach(l => {
    html += `<tr>
      <td>${l.leaveType.leavename}</td>
      <td>${l.fromDate}</td><td>${l.toDate}</td>
      <td>${l.appliedDate}</td>
      <td>${l.reason}</td>
      <td><span class="badge ${l.status}">${l.status}</span></td>
    </tr>`;
  });
  document.getElementById('historyTable').innerHTML = html;
}
async function applyLeave() {
  const msgBox = document.getElementById('formMsg');

  msgBox.style.display = 'block';
  msgBox.className = 'msg-loading';
  msgBox.innerText = 'Submitting request...';

  const body = {
    ltid: parseInt(document.getElementById('leaveType').value),
    fromDate: document.getElementById('fromDate').value,
    toDate: document.getElementById('toDate').value,
    reason: document.getElementById('reason').value,
    halfDay: document.getElementById('halfDay').value === 'true'
  };

  try {
    const res = await fetch('/api/employee/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(r => r.json());

    if (res.message === 'SUCCESS') {
      msgBox.className = 'msg-success';
      msgBox.innerText = 'Leave applied successfully!';

      document.getElementById('leaveForm').reset();
      document.getElementById('dayCount').innerText = '';

      loadDashboard();
    } else {
      msgBox.className = 'msg-error';
      msgBox.innerText = 'Failed to apply leave';
    }

  } catch (err) {
    msgBox.className = 'msg-error';
    msgBox.innerText = 'Something went wrong';
  }

  setTimeout(() => {
    msgBox.style.display = 'none';
  }, 3000);
}
loadDashboard();

function logout() {
  window.location.href = 'api/auth/logout';
}
