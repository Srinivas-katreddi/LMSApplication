package org.example.lmsapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
